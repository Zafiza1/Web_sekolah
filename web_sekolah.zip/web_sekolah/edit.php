<?php
include 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM siswa WHERE id = $id");
    $data = $result->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];
    $umur = $_POST['umur'];

    $sql = "UPDATE siswa SET nama='$nama', kelas='$kelas', umur='$umur' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        echo "Data berhasil diupdate!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Siswa</title>
</head>
<body>
    <h2>Edit Siswa</h2>
    <form method="POST" action="">
        <input type="hidden" name="id" value="<?= $data['id'] ?>">
        Nama: <input type="text" name="nama" value="<?= $data['nama'] ?>"><br>
        Kelas: <input type="text" name="kelas" value="<?= $data['kelas'] ?>"><br>
        Umur: <input type="number" name="umur" value="<?= $data['umur'] ?>"><br>
        <input type="submit" value="Update">
    </form>
</body>
</html>
