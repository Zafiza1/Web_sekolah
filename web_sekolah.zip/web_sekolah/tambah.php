<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];
    $umur = $_POST['umur'];

    $sql = "INSERT INTO siswa (nama, kelas, umur) VALUES ('$nama', '$kelas', '$umur')";
    if ($conn->query($sql) === TRUE) {
        echo "Data berhasil ditambahkan!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Siswa</title>
</head>
<body>
    <h2>Tambah Siswa</h2>
    <form method="POST" action="">
        Nama: <input type="text" name="nama"><br>
        Kelas: <input type="text" name="kelas"><br>
        Umur: <input type="number" name="umur"><br>
        <input type="submit" value="Tambah">
    </form>
</body>
</html>
